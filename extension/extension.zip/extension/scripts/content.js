const initCommunication = async () => {
    const htspContainer = document.getElementById("HTSP_Extension_Identifier-1983dd3617d04cc7b69ee9ea7af7fe90");

    const extensionData = {
        version: "1.0"
    }

    if (htspContainer) {
        htspContainer.innerText = JSON.stringify(extensionData);
    }

    //better alternative?
    document.addEventListener('saveUserPreference', (data) => {
        chrome.storage.local.set({ userPreference: data.detail });
        console.log("data", data, data.detail)
    });

    var storedData = await chrome.storage.local.get(["userPreference"]);
    extensionData.userPreference = storedData.userPreference;

    document.dispatchEvent(new CustomEvent('spineExtensionData', extensionData));
};

initCommunication();
