chrome.runtime.onInstalled.addListener(() => {
    chrome.alarms.create("notification", {
        periodInMinutes: 1
    });
});

const imgCount = 14;

chrome.alarms.onAlarm.addListener((alarm) => {
    if (alarm.name === "notification") {
        chrome.storage.local.get(["startTime", "lastNotification", "userPreference", "nextNotification"]).then(storedTime => {
            if (storedTime.nextNotification && storedTime.nextNotification < new Date().getTime()) {
                var timestring = "";
                const minutesSinceStart = (Date.now() - storedTime.startTime) / (60 * 1000);

                if (minutesSinceStart >= 60) {
                    timestring += ` ${Math.floor(minutesSinceStart / 60)} Stunden`;
                }
                // there won't be an interval shorter than five minutes, so timestring will never be empty
                if (minutesSinceStart % 60 > 5) {
                    // round to five minute increments
                    timestring += ` ${Math.floor((minutesSinceStart % 60) / 5) * 5} Minuten`
                }
                chrome.notifications.create(Date.now().toString(), {
                    title: "RückgratRetter",
                    message: `Du arbeitest schon seit${timestring}.\nDeine Rücken leidet! Mach eine Pause`,
                    iconUrl: "https://placekitten.com/50/50",
                    type: "basic"
                })

                chrome.storage.local.set({
                    lastNotification: Date.now(),
                    showExercise: Math.ceil(Math.random() * imgCount),
                    nextNotification: null
                });
            }
        })
    }
});

chrome.notifications.onClicked.addListener(
    () => {
        chrome.tabs.create({ url: 'https://rueckgratretter.github.io/rr/' });
    }
);
