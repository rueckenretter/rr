chrome.runtime.onInstalled.addListener(() => {
    chrome.alarms.create("notification", {
        periodInMinutes: 1
    });
});

//TODO: get from settings
var notificationMinutes = 5;

chrome.alarms.onAlarm.addListener((alarm) => {
    if (alarm.name === "notification") {
        chrome.storage.local.get(["startTime", "lastNotification"]).then(storedTime => {
            console.log(storedTime)
            if (storedTime.startTime) {
                //used to determine wether notification should be sent
                const diffMinutes = (Date.now() - (storedTime.lastNotification || storedTime.startTime)) / (60 * 1000);
                // used to display total working time
                const minutesSinceStart = (Date.now() - storedTime.startTime) / (60 * 1000);

                if (diffMinutes > notificationMinutes) {
                    var timestring = "";
                    if (minutesSinceStart >= 60) {
                        timestring += ` ${Math.floor(minutesSinceStart / 60)} Stunden`;
                    }
                    // there won't be an interval shorter than five minutes, so timestring will never be empty
                    if (minutesSinceStart % 60 > 5) {
                        // round to five minute increments
                        timestring += ` ${Math.floor((minutesSinceStart % 60) / 5) * 5} Minuten`
                    }
                    chrome.notifications.create(Date.now().toString(), {
                        title: "RückgratRetter",
                        message: `Du arbeitest schon seit${timestring}.\nDeine Rücken leidet! Mach eine Pause`,
                        iconUrl: "https://placekitten.com/50/50",
                        type: "basic"
                    })

                    chrome.storage.local.set({ lastNotification: Date.now() })
                }
            }
        })
    }
});

chrome.notifications.onClicked.addListener(
    () => {
        chrome.tabs.create({ url: 'https://rueckgratretter.github.io/rr/' });
    }
);
