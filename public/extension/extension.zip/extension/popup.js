let startTime;
let interval;

const init = async () => {
    const storedTime = await chrome.storage.local.get(["startTime"]);
    console.log("storedTime", storedTime)
    if (storedTime.startTime) {
        startTime = new Date(storedTime.startTime);

        const container = document.getElementById("timer-container");
        if (container !== null) {
            container.innerHTML = formatTimeDifference(startTime);
            interval = setInterval(() => {
                container.innerHTML = formatTimeDifference(startTime);
            }, 1000);
        }
        toggleDancingDude(true);
    }

    const btn = document.getElementById("timer-controll");
    if (btn) {
        btn.onclick = handleClick;
        if (storedTime.startTime) {
            btn.innerText = "Stop";
        }
    }
};

const handleClick = () => {
    if (!startTime) {
        startTime = new Date();
        chrome.storage.local.set({ startTime: startTime.getTime() })
        const container = document.getElementById("timer-container");
        if (container !== null) {
            interval = setInterval(() => {
                container.innerHTML = formatTimeDifference(startTime);
            }, 1000);
        }
        const btn = document.getElementById("timer-controll");
        if (btn) {
            btn.innerText = "Stop";
        }
        toggleDancingDude(true);
    } else {
        clearInterval(interval);
        startTime = null;
        // clear last notification to avoid message triggering directly after restarting timer
        chrome.storage.local.set({ startTime: null, lastNotification: null });
        const btn = document.getElementById("timer-controll");
        if (btn) {
            btn.innerText = "Start";
        }
        const container = document.getElementById("timer-container");
        if (container !== null) {
            container.innerText = "00:00";
        }
        toggleDancingDude(false);
    }
};

const formatTimeDifference = (startDate, endDate = new Date()) => {
    const diffInSeconds = Math.floor((endDate.getTime() - startDate.getTime()) / 1000);
    const seconds = formatTwoDigits(diffInSeconds % 60);
    const diffInMinutes = Math.floor(diffInSeconds / 60);
    const minutes = formatTwoDigits(diffInMinutes % 60);
    const diffInHours = Math.floor(diffInMinutes / 60);
    const hours = formatTwoDigits(diffInHours % 60);
    return diffInHours === 0
        ? `${minutes}:${seconds}`
        : `${hours}:${minutes}:${seconds}`;
};

const formatTwoDigits = (number) => (
    `00${number}`.slice(-2)
);

const toggleDancingDude = (showDude) => {
    const dudeElement = document.getElementById("dancing-dude");
    if (dudeElement) {
        if (showDude) {
            // has to be the number of gifs
            const imgCount = 11;
            const rnd = Math.ceil(Math.random() * imgCount);
            dudeElement.src = `images/Gif_${rnd}.gif`
            dudeElement.classList.remove('hidden');
        } else {
            dudeElement.classList.add('hidden');
        }
    }
};

init();
